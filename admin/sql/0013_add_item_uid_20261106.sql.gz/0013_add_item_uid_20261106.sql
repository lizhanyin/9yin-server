-- 0013_add_item_uid_20261106.sql
-- 物品实例稳定 UID：role_bag_items / role_equip_items 各加 uid CHAR(16)。
-- 背景（2026-11-06 真机两轮修复定稿）：客户端 item 快捷方式/一键穿按 ViewAdd 下发的
-- UniqueID 引用物品实例（shortcut_game.lua FindItemInBagByUID），官服 UID=实例身份
-- （61114 抓包镜像双视图同 UID）；bak 方言 MD5(role:kind:slot) 槽位寻址，物品穿脱/
-- 移位后旧 UID 命中同槽位的其他物品 → 内功快捷栏图标漂移成别的物品。
-- 语义：入包/入装时生成全局随机 16 hex（SecureRandom，与角色/槽位无关）；穿脱跨表
-- 移动、同表换槽全程携带；upsertEquip 按槽位保留既有 uid。旧行 uid=NULL 读取时按
-- MD5(role:kind:seq) 派生（表内主键稳定）——无需回填，重放幂等。

SET @bag_col = (SELECT COUNT(*) FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'role_bag_items'
    AND COLUMN_NAME = 'uid');
SET @bag_ddl = IF(@bag_col = 0,
  'ALTER TABLE `role_bag_items` ADD COLUMN `uid` CHAR(16) NULL DEFAULT NULL AFTER `seq`',
  'SELECT 1');
PREPARE stmt FROM @bag_ddl;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @eq_col = (SELECT COUNT(*) FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'role_equip_items'
    AND COLUMN_NAME = 'uid');
SET @eq_ddl = IF(@eq_col = 0,
  'ALTER TABLE `role_equip_items` ADD COLUMN `uid` CHAR(16) NULL DEFAULT NULL AFTER `seq`',
  'SELECT 1');
PREPARE stmt FROM @eq_ddl;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
