-- 0011_add_role_mounts_and_idle_stance_20261105.sql
-- GM 面板「外观与坐骑」补全：坐骑 + 待机站姿两张角色级新表。
-- role_mounts 沿用库内既有表结构（role 618 官服迁移数据在档：snapshot 数组
-- 元素 ConfigID/StaticID/UsedDate/ValidTime/Selected，即 NewRideRec 列镜像；
-- 本迁移在缺表环境重建同构表——线上库已有表时 IF NOT EXISTS 零改动）。幂等可重放。

-- 坐骑拥有快照（data/坐骑.json 的 DB 双源；MountStore 读写）。
CREATE TABLE IF NOT EXISTS `role_mounts` (
  `role_id` bigint unsigned NOT NULL,
  `snapshot` json NOT NULL,
  `updated_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`role_id`),
  CONSTRAINT `fk_role_mounts_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`role_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 待机站姿（data/待机站姿.json 的 DB 双源；stance_action = 客户端
-- b_action_index.ini 节名，空串 = 默认站姿；下发通道 PlayActionName 属性）。
CREATE TABLE IF NOT EXISTS `role_idle_stance` (
  `role_id` bigint unsigned NOT NULL,
  `stance_action` varchar(64) NOT NULL DEFAULT '',
  `version` bigint unsigned NOT NULL DEFAULT '1',
  `updated_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`role_id`),
  CONSTRAINT `fk_idle_stance_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`role_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
