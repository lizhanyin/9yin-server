-- 0003_role_equip_affixes_20261101.sql
-- 四期面板实时化：role_equip_items 补挂 affixes JSON 列（装备词缀
-- [{pack_rec,prop_built}]，登录链 propBuilt 解析 → proppack 累积层的输入）。
-- 与 tools/data-import 的 ensureAffixesColumn 同款幂等（information_schema 守护），
-- 升级重放安全；老 F 版数据还原库无该列时服务端查询自动降级。

SET @has_affixes := (
    SELECT COUNT(*) FROM information_schema.COLUMNS
    WHERE table_schema = DATABASE()
      AND table_name = 'role_equip_items'
      AND column_name = 'affixes'
);
SET @ddl := IF(@has_affixes = 0,
    'ALTER TABLE role_equip_items ADD COLUMN affixes JSON NULL',
    'SELECT 1');
PREPARE stmt FROM @ddl;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
