
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `accounts` (
  `account_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `account_key` varbinary(128) NOT NULL,
  `password_hash` varbinary(255) DEFAULT NULL,
  `status` tinyint unsigned NOT NULL DEFAULT '1',
  `agreed_terms` tinyint(1) NOT NULL DEFAULT '0' COMMENT '同意用户须知：0=未同意 1=已同意',
  `agreed_terms_at` timestamp(6) NULL DEFAULT NULL COMMENT '同意用户须知时间',
  `version` bigint unsigned NOT NULL DEFAULT '1',
  `created_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updated_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`account_id`),
  UNIQUE KEY `uq_accounts_key` (`account_key`),
  CONSTRAINT `ck_accounts_status` CHECK ((`status` in (0,1,2)))
) ENGINE=InnoDB AUTO_INCREMENT=230 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `game_cards` (
  `card_id` int unsigned NOT NULL,
  `name` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `config_id` int unsigned NOT NULL DEFAULT '0',
  `item_type` int NOT NULL DEFAULT '0',
  `level` int NOT NULL DEFAULT '0',
  `main_type` int NOT NULL DEFAULT '0',
  `sub_type` int NOT NULL DEFAULT '0',
  `flag` int NOT NULL DEFAULT '0',
  `female_model_data` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `male_model_data` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`card_id`),
  KEY `ix_game_cards_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `game_feature_switches` (
  `switch_id` int unsigned NOT NULL,
  `desc_key` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `label` varchar(512) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `enabled` tinyint unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`switch_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `game_gift_boxes` (
  `box_id` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `seq` int unsigned NOT NULL,
  `item_id` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `min_amount` int NOT NULL DEFAULT '1',
  `max_amount` int NOT NULL DEFAULT '1',
  `weight` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`box_id`,`seq`),
  KEY `ix_game_gift_boxes_item` (`item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `game_identity_suits` (
  `suit_id` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `qname` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `item_type` int NOT NULL DEFAULT '0',
  `need_sex` tinyint unsigned NOT NULL DEFAULT '0',
  `color_level` int NOT NULL DEFAULT '0',
  `condition_id` int NOT NULL DEFAULT '0',
  `parts` json DEFAULT NULL,
  PRIMARY KEY (`suit_id`),
  KEY `ix_game_identity_suits_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `game_item_effects` (
  `config_id` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `heal_hp` int DEFAULT NULL,
  `heal_mp` int DEFAULT NULL,
  `consume` tinyint unsigned NOT NULL DEFAULT '0',
  `effects` json DEFAULT NULL,
  PRIMARY KEY (`config_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `game_items` (
  `item_id` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `item_category` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `item_name` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `item_type` int NOT NULL DEFAULT '0',
  `view_id` int NOT NULL DEFAULT '0',
  `equip_type` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `script` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `max_amount` int NOT NULL DEFAULT '0',
  `func_pack` int NOT NULL DEFAULT '0',
  `logic_pack` int NOT NULL DEFAULT '0',
  `prop_modify_pack` int NOT NULL DEFAULT '0',
  `texture_type` int NOT NULL DEFAULT '0',
  `art_pack` int NOT NULL DEFAULT '0',
  `hardiness` int NOT NULL DEFAULT '0',
  `max_hardiness` int NOT NULL DEFAULT '0',
  `source_file` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`item_id`),
  KEY `idx_game_items_category` (`item_category`),
  KEY `idx_game_items_name` (`item_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `game_meridians` (
  `meridian_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `static_data` int NOT NULL DEFAULT '0',
  `item_type` int NOT NULL DEFAULT '0',
  `neigong` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `max_level` int NOT NULL DEFAULT '0',
  `attrs` json DEFAULT NULL,
  `per_level` json DEFAULT NULL,
  PRIMARY KEY (`meridian_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `game_ninjiuzhi_overrides` (
  `category` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `item_key` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `required_stage` tinyint unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`category`,`item_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `game_npc_shops` (
  `npc_config_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `npc_name` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `shop_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`npc_config_id`),
  KEY `ix_game_npc_shops_shop` (`shop_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `game_origin_conditions` (
  `condition_id` int unsigned NOT NULL,
  `text` varchar(512) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `use_count` int NOT NULL DEFAULT '0',
  `note` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`condition_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `game_origins` (
  `origin_id` int unsigned NOT NULL,
  `name` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `category` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `sub_category` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `type1` int NOT NULL DEFAULT '0',
  `type2` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `level` int NOT NULL DEFAULT '0',
  `material` int NOT NULL DEFAULT '0',
  `body_type` int NOT NULL DEFAULT '0',
  `line` json DEFAULT NULL,
  `conditions` json DEFAULT NULL,
  PRIMARY KEY (`origin_id`),
  KEY `ix_game_origins_name` (`name`),
  KEY `ix_game_origins_type2` (`type2`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `game_shop_items` (
  `shop_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `seq` int unsigned NOT NULL,
  `config_id` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` int NOT NULL DEFAULT '1',
  `capital_type` tinyint unsigned NOT NULL DEFAULT '0',
  `price` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`shop_id`,`seq`),
  KEY `ix_game_shop_items_config` (`config_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `game_shops` (
  `shop_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `shop_name` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`shop_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `game_skill_reactions` (
  `skill_id` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reaction` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `final_hit_only` tinyint unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`skill_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `game_skills` (
  `skill_id` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `skill_type` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `skill_name` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `static_data` int NOT NULL DEFAULT '0',
  `item_type` int NOT NULL DEFAULT '0',
  `qtype_id` int NOT NULL DEFAULT '0',
  `script` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `school` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `source_file` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`skill_id`),
  KEY `idx_game_skills_type` (`skill_type`),
  KEY `idx_game_skills_name` (`skill_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `game_stat_defaults` (
  `stat_key` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `stat_value` bigint NOT NULL DEFAULT '0',
  `updated_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`stat_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `game_titles` (
  `title_id` int unsigned NOT NULL,
  `name` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `title_type` smallint unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`title_id`),
  KEY `ix_game_titles_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `gm_permissions` (
  `scope` varchar(8) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject_key` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gm_level` int NOT NULL DEFAULT '1',
  `updated_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`scope`,`subject_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `role_appearances` (
  `role_id` bigint unsigned NOT NULL,
  `format_version` smallint unsigned NOT NULL DEFAULT '1',
  `appearance` json NOT NULL,
  `version` bigint unsigned NOT NULL DEFAULT '1',
  `updated_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`role_id`),
  CONSTRAINT `fk_appearance_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`role_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `role_bag_items` (
  `role_id` bigint unsigned NOT NULL,
  `seq` int unsigned NOT NULL,
  `slot` int DEFAULT NULL,
  `config_id` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `item_type` int NOT NULL,
  `amount` int NOT NULL,
  `view_id` int NOT NULL,
  `name` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `equip_type` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `color_level` int DEFAULT NULL,
  `script` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `valid_type` int DEFAULT NULL,
  `anchor_slot` int DEFAULT NULL,
  `expires_at` datetime(6) DEFAULT NULL,
  `art_pack` int DEFAULT NULL,
  `hardiness` int DEFAULT NULL,
  `max_hardiness` int DEFAULT NULL,
  `updated_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`role_id`,`seq`),
  CONSTRAINT `fk_bag_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`role_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `role_bagpacks` (
  `role_id` bigint unsigned NOT NULL,
  `page` tinyint unsigned NOT NULL COMMENT '页族 1道具 2装备 3材料 4任务（tool_item ViewID）',
  `anchor` tinyint unsigned NOT NULL COMMENT '锚点位 1/2（每页两个）',
  `config_id` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `boost` int NOT NULL COMMENT '该锚点扩容格数',
  `expires_at` datetime(6) NOT NULL COMMENT '到期时间；9999-12-31 为存量种子（永久）',
  `updated_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`role_id`,`page`,`anchor`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='背包扩容包锚点';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `role_binglu` (
  `role_id` bigint unsigned NOT NULL,
  `binglu_index` tinyint unsigned NOT NULL,
  `cur_level` int NOT NULL DEFAULT '0',
  `fill_value` bigint NOT NULL DEFAULT '0',
  `max_level` int NOT NULL DEFAULT '0',
  `updated_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`role_id`,`binglu_index`),
  CONSTRAINT `fk_binglu_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`role_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `role_buffs` (
  `role_id` bigint unsigned NOT NULL,
  `snapshot` json NOT NULL,
  `version` bigint unsigned NOT NULL DEFAULT '1',
  `updated_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`role_id`),
  CONSTRAINT `fk_buffs_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`role_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `role_clone_usage` (
  `role_id` bigint unsigned NOT NULL,
  `usage_date` date NOT NULL,
  `scene_config` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `used` json NOT NULL,
  `updated_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`role_id`,`usage_date`,`scene_config`),
  CONSTRAINT `fk_clone_usage_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`role_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `role_currency` (
  `role_id` bigint unsigned NOT NULL,
  `snapshot` json NOT NULL,
  `version` bigint unsigned NOT NULL DEFAULT '1',
  `updated_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`role_id`),
  CONSTRAINT `fk_currency_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`role_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `role_customizing` (
  `role_id` bigint unsigned NOT NULL,
  `customizing_value` longblob NOT NULL,
  `updated_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`role_id`),
  CONSTRAINT `fk_customizing_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`role_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `role_dressing` (
  `role_id` bigint unsigned NOT NULL,
  `blend` json NOT NULL,
  `show_type` int NOT NULL DEFAULT '0',
  `updated_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`role_id`),
  CONSTRAINT `fk_dressing_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`role_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `role_equip_items` (
  `role_id` bigint unsigned NOT NULL,
  `seq` int unsigned NOT NULL,
  `config_id` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `item_type` int NOT NULL,
  `equip_type` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hardiness` int NOT NULL,
  `max_hardiness` int NOT NULL,
  `slot` int NOT NULL,
  `art_pack` int DEFAULT NULL,
  `updated_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`role_id`,`seq`),
  CONSTRAINT `fk_equip_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`role_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `role_faculty` (
  `role_id` bigint unsigned NOT NULL,
  `snapshot` json NOT NULL,
  `version` bigint unsigned NOT NULL DEFAULT '1',
  `updated_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`role_id`),
  CONSTRAINT `fk_faculty_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`role_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `role_fashion_suits` (
  `role_id` bigint unsigned NOT NULL,
  `suit_id` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `updated_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`role_id`,`suit_id`),
  CONSTRAINT `fk_fashion_suits_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`role_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `role_fwz` (
  `role_id` bigint unsigned NOT NULL,
  `card_id` int NOT NULL,
  `is_used` tinyint NOT NULL DEFAULT '0',
  `is_worn` tinyint NOT NULL DEFAULT '0',
  `worn_pos` int NOT NULL DEFAULT '0',
  `updated_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`role_id`,`card_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `role_fwz_suits` (
  `role_id` bigint unsigned NOT NULL,
  `suit_index` int NOT NULL,
  `card_pos` int NOT NULL,
  `card_id` int NOT NULL,
  `updated_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`role_id`,`suit_index`,`card_pos`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `role_homepoint_hires` (
  `role_id` bigint unsigned NOT NULL,
  `point_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `point_type` tinyint unsigned NOT NULL DEFAULT '0',
  `updated_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`role_id`,`point_id`),
  CONSTRAINT `fk_homepoint_hires_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`role_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `role_homepoint_state` (
  `role_id` bigint unsigned NOT NULL,
  `home_point_count` int NOT NULL DEFAULT '0',
  `guild_count` int NOT NULL DEFAULT '0',
  `jianghu_count` int NOT NULL DEFAULT '0',
  `school_count` int NOT NULL DEFAULT '0',
  `hire_expires_unix` bigint NOT NULL DEFAULT '0',
  `updated_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`role_id`),
  CONSTRAINT `fk_homepoint_state_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`role_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `role_homepoints` (
  `role_id` bigint unsigned NOT NULL,
  `point_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `point_type` tinyint unsigned NOT NULL DEFAULT '0',
  `updated_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`role_id`,`point_id`),
  CONSTRAINT `fk_homepoints_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`role_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `role_jingmai` (
  `role_id` bigint unsigned NOT NULL,
  `snapshot` json NOT NULL,
  `version` bigint unsigned NOT NULL DEFAULT '1',
  `updated_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`role_id`),
  CONSTRAINT `fk_jingmai_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`role_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `role_keybinds` (
  `role_id` bigint unsigned NOT NULL,
  `bind_value` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `shortcut_key1` varchar(4096) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `shortcut_key2` varchar(4096) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `updated_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`role_id`),
  CONSTRAINT `fk_keybinds_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`role_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `role_lifejob_jobs` (
  `role_id` bigint unsigned NOT NULL,
  `job_id` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `level` int NOT NULL DEFAULT '1',
  `exp` bigint NOT NULL DEFAULT '0',
  `next_exp` bigint NOT NULL DEFAULT '0',
  `formulas` int NOT NULL DEFAULT '0',
  `points` int NOT NULL DEFAULT '0',
  `updated_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`role_id`,`job_id`),
  CONSTRAINT `fk_lifejob_jobs_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`role_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `role_lifejob_state` (
  `role_id` bigint unsigned NOT NULL,
  `ene` int NOT NULL DEFAULT '0',
  `updated_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`role_id`),
  CONSTRAINT `fk_lifejob_state_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`role_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `role_locations` (
  `role_id` bigint unsigned NOT NULL,
  `scene_config` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `scene_resource` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pos_x` float NOT NULL,
  `pos_y` float NOT NULL,
  `pos_z` float NOT NULL,
  `orient` float NOT NULL,
  `version` bigint unsigned NOT NULL DEFAULT '1',
  `updated_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`role_id`),
  KEY `ix_role_locations_scene` (`scene_resource`),
  CONSTRAINT `fk_location_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`role_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `role_mails` (
  `role_id` bigint unsigned NOT NULL,
  `mail_serial` varchar(96) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_unix` bigint NOT NULL,
  `sender_id` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `title_id` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `content_id` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `is_read` tinyint unsigned NOT NULL DEFAULT '0',
  `attachment_config_id` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attachment_amount` int unsigned DEFAULT NULL,
  `attachment_claimed` tinyint unsigned NOT NULL DEFAULT '0',
  `updated_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`role_id`,`mail_serial`),
  KEY `ix_role_mails_created` (`role_id`,`created_unix`),
  CONSTRAINT `fk_mails_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`role_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `role_mounts` (
  `role_id` bigint unsigned NOT NULL,
  `snapshot` json NOT NULL,
  `updated_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`role_id`),
  CONSTRAINT `fk_role_mounts_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`role_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `role_origin_progress` (
  `role_id` bigint unsigned NOT NULL,
  `activated` json NOT NULL,
  `updated_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`role_id`),
  CONSTRAINT `fk_origin_progress_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`role_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `role_qinggong` (
  `role_id` bigint unsigned NOT NULL,
  `snapshot` json NOT NULL,
  `version` bigint unsigned NOT NULL DEFAULT '1',
  `updated_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`role_id`),
  CONSTRAINT `fk_qinggong_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`role_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `role_relive` (
  `role_id` bigint unsigned NOT NULL,
  `scene_config` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `scene_resource` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `pos_x` float NOT NULL DEFAULT '0',
  `pos_y` float NOT NULL DEFAULT '0',
  `pos_z` float NOT NULL DEFAULT '0',
  `orient` float NOT NULL DEFAULT '0',
  `ui_name` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `home_point_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `is_manual` tinyint unsigned NOT NULL DEFAULT '0',
  `affiliation` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `updated_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`role_id`),
  CONSTRAINT `fk_relive_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`role_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `role_repute` (
  `role_id` bigint unsigned NOT NULL,
  `repute_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `repute_value` bigint NOT NULL DEFAULT '0',
  `updated_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`role_id`,`repute_id`),
  CONSTRAINT `fk_repute_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`role_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `role_shortcuts` (
  `role_id` bigint unsigned NOT NULL,
  `seq` int unsigned NOT NULL,
  `shortcut_index` int NOT NULL,
  `kind` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `id` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `updated_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`role_id`,`seq`),
  KEY `ix_role_shortcuts_index` (`role_id`,`shortcut_index`),
  CONSTRAINT `fk_shortcuts_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`role_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `role_skill_progress` (
  `role_id` bigint unsigned NOT NULL,
  `skill_config_id` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `level` int NOT NULL DEFAULT '1',
  `max_level` int NOT NULL DEFAULT '1',
  `fill` bigint NOT NULL DEFAULT '0',
  `total` bigint NOT NULL DEFAULT '0',
  `extra` json DEFAULT NULL,
  `updated_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`role_id`,`skill_config_id`),
  CONSTRAINT `fk_skill_progress_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`role_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `role_skills` (
  `role_id` bigint unsigned NOT NULL,
  `skill_type` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `skill_id` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `granted_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`role_id`,`skill_id`),
  KEY `idx_role_skills_type` (`role_id`,`skill_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `role_stances` (
  `role_id` bigint unsigned NOT NULL,
  `idle_stance` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `updated_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`role_id`),
  CONSTRAINT `fk_stances_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`role_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `role_stat_snapshots` (
  `role_id` bigint unsigned NOT NULL,
  `archived_unix` bigint NOT NULL,
  `snapshot` json NOT NULL,
  PRIMARY KEY (`role_id`,`archived_unix`),
  CONSTRAINT `fk_stat_snapshots_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`role_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `role_story_tasks` (
  `role_id` bigint unsigned NOT NULL,
  `task_id` int unsigned NOT NULL,
  `status` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `step` int NOT NULL DEFAULT '1',
  `counts` json DEFAULT NULL,
  `completed_unix` bigint DEFAULT NULL,
  `updated_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`role_id`,`task_id`),
  KEY `ix_role_story_tasks_status` (`role_id`,`status`),
  CONSTRAINT `fk_story_tasks_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`role_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `role_titles` (
  `role_id` bigint unsigned NOT NULL,
  `title_id` int unsigned NOT NULL,
  `title_type` smallint unsigned NOT NULL DEFAULT '1',
  `is_worn` tinyint unsigned NOT NULL DEFAULT '0',
  `obtained_unix` bigint DEFAULT NULL,
  `updated_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`role_id`,`title_id`),
  KEY `ix_role_titles_worn` (`role_id`,`is_worn`),
  CONSTRAINT `fk_titles_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`role_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `role_vip` (
  `role_id` bigint unsigned NOT NULL,
  `gold` bigint unsigned NOT NULL DEFAULT '0',
  `guan_yin` bigint unsigned NOT NULL DEFAULT '0',
  `vip_valid_until` bigint NOT NULL DEFAULT '0',
  `vip_total_time` bigint NOT NULL DEFAULT '0',
  `vip_flag` int NOT NULL DEFAULT '0',
  `vip_prize_time` bigint NOT NULL DEFAULT '0',
  `version` bigint unsigned NOT NULL DEFAULT '1',
  `updated_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`role_id`),
  CONSTRAINT `fk_vip_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`role_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `role_wuji_learned` (
  `role_id` bigint unsigned NOT NULL,
  `art_id` int unsigned NOT NULL,
  `level` int NOT NULL DEFAULT '0',
  `is_active` tinyint unsigned NOT NULL DEFAULT '0',
  `updated_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`role_id`,`art_id`),
  CONSTRAINT `fk_wuji_learned_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`role_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `role_wuji_unlocked` (
  `role_id` bigint unsigned NOT NULL,
  `group_id` tinyint unsigned NOT NULL,
  `unlocked_count` int NOT NULL DEFAULT '0',
  `updated_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`role_id`,`group_id`),
  CONSTRAINT `fk_wuji_unlocked_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`role_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `role_wuji_worn` (
  `role_id` bigint unsigned NOT NULL,
  `group_id` tinyint unsigned NOT NULL,
  `slot_index` tinyint unsigned NOT NULL,
  `art_id` int unsigned NOT NULL DEFAULT '0',
  `updated_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`role_id`,`group_id`,`slot_index`),
  CONSTRAINT `fk_wuji_worn_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`role_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `roles` (
  `role_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `account_id` bigint unsigned NOT NULL,
  `slot` smallint unsigned NOT NULL,
  `name` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `delete_requested_at` timestamp(6) NULL DEFAULT NULL,
  `version` bigint unsigned NOT NULL DEFAULT '1',
  `created_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updated_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  `role_ext` json DEFAULT NULL,
  PRIMARY KEY (`role_id`),
  UNIQUE KEY `uq_roles_account_slot` (`account_id`,`slot`),
  UNIQUE KEY `uq_roles_name` (`name`),
  KEY `ix_roles_account` (`account_id`)
) ENGINE=InnoDB AUTO_INCREMENT=723 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `schema_migrations` (
  `version` bigint unsigned NOT NULL,
  `name` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `checksum` binary(32) NOT NULL,
  `applied_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `server_bots` (
  `bot_id` int unsigned NOT NULL AUTO_INCREMENT,
  `bot_key` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `enabled` tinyint unsigned NOT NULL DEFAULT '1',
  `scene` json DEFAULT NULL,
  `position` json DEFAULT NULL,
  `equipment` json DEFAULT NULL,
  `appearance` json DEFAULT NULL,
  `revision` bigint unsigned NOT NULL DEFAULT '1',
  `updated_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`bot_id`),
  UNIQUE KEY `uq_server_bots_key` (`bot_key`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `server_config` (
  `config_key` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `config_value` json NOT NULL,
  `updated_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`config_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `server_dummy_players` (
  `dummy_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `sex` tinyint unsigned NOT NULL DEFAULT '0',
  `school` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `level` int NOT NULL DEFAULT '0',
  `power_level` int NOT NULL DEFAULT '0',
  `character_type` int NOT NULL DEFAULT '0',
  `scene` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `action` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `neigong_buff` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `position` json DEFAULT NULL,
  `appearance` json DEFAULT NULL,
  PRIMARY KEY (`dummy_id`),
  KEY `ix_server_dummy_players_scene` (`scene`),
  KEY `ix_server_dummy_players_name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=31926 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `server_list` (
  `server_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '区服显示名，svrlist # 后的未转义原文',
  `host` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '游戏网关地址',
  `port` int unsigned NOT NULL COMMENT '游戏网关端口',
  `status` tinyint unsigned NOT NULL DEFAULT '0' COMMENT '0=可进入（svrlist 尾部标志实测为 0） 1=维护 2=隐藏',
  `sort_order` int unsigned NOT NULL DEFAULT '0' COMMENT '列表展示顺序，小在前',
  `created_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updated_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`server_id`),
  UNIQUE KEY `uq_server_list_name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='区服列表';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `server_ninjiuzhi` (
  `id` tinyint unsigned NOT NULL DEFAULT '1',
  `stage` tinyint unsigned NOT NULL DEFAULT '1',
  `active` tinyint unsigned NOT NULL DEFAULT '0',
  `points` bigint NOT NULL DEFAULT '0',
  `events` json DEFAULT NULL,
  `revision` bigint unsigned NOT NULL DEFAULT '1',
  `updated_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `team_members` (
  `team_id` int unsigned NOT NULL,
  `role_id` bigint unsigned NOT NULL,
  `joined_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`team_id`,`role_id`),
  UNIQUE KEY `uq_team_members_role` (`role_id`),
  CONSTRAINT `fk_team_members_team` FOREIGN KEY (`team_id`) REFERENCES `teams` (`team_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `teams` (
  `team_id` int unsigned NOT NULL AUTO_INCREMENT,
  `leader_role_id` bigint unsigned DEFAULT NULL,
  `extra` json DEFAULT NULL,
  `created_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updated_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`team_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

