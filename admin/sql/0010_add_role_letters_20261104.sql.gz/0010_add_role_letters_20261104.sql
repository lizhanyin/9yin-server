-- 0010_add_role_letters_20261104.sql
-- 邮件系统：新表 role_letters（角色级快照，data/letters.json 的 DB 双源）。
-- 结构对齐基线快照表 role_tasks（role_id PK + snapshot json + version + updated_at，
-- FK roles ON DELETE CASCADE）；LetterStore.attachDatabase 里有同款
-- CREATE TABLE IF NOT EXISTS 运行期兜底。
-- 快照 JSON 形态：{"letters":[{"serial":str,"type":int,"sender":str,
-- "sender_uid":str,"title":str,"content":str,"gold":str,"silver":str,
-- "appendix_xml":str,"date_unix_seconds":int64,"read_flag":bool}]}
-- （GoJson MarshalIndent 兼容输出；RecvLetterRec 记录行的服务端镜像）。

CREATE TABLE IF NOT EXISTS `role_letters` (
  `role_id` bigint unsigned NOT NULL,
  `snapshot` json NOT NULL,
  `version` bigint unsigned NOT NULL DEFAULT '1',
  `updated_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`role_id`),
  CONSTRAINT `fk_letters_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`role_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
