-- 0012_add_role_origins_20261105.sql
-- GM 身份系统（origin）：role_origins 已激活/已领奖集合（Origin_Active/Origin_Prized
-- 记录行的 DB 双源）。status：1=已激活（GM origin_activate_all / C2S 700）、
-- 2=已领奖（C2S 702 物品+称号+声望全部落袋后升级，只进不退）。幂等可重放。

CREATE TABLE IF NOT EXISTS `role_origins` (
  `role_id` bigint unsigned NOT NULL,
  `origin_id` int unsigned NOT NULL,
  `status` tinyint unsigned NOT NULL DEFAULT '1',
  `updated_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`role_id`,`origin_id`),
  CONSTRAINT `fk_origins_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`role_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
